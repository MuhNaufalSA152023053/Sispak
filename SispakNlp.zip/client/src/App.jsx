import ConsultationContainer from "./components/ConsultationContainer.jsx";

function App() {
  return <ConsultationContainer />;
}

export default App;
