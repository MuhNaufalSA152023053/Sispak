const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:4000/api";

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers ?? {})
    },
    ...options
  });

  const payload = await response.json().catch(() => ({}));

  if (!response.ok) {
    const message = payload?.error ?? "Terjadi kesalahan saat menghubungi server inferensi.";
    throw new Error(message);
  }

  return payload;
}

export function fetchGoals() {
  return request("/goals");
}

export function startConsultation(goalId) {
  return request("/consultations/start", {
    method: "POST",
    body: JSON.stringify({ goalId })
  });
}

export function answerQuestion(sessionId, factId, value) {
  return request(`/consultations/${sessionId}/answer`, {
    method: "POST",
    body: JSON.stringify({ factId, value })
  });
}

/**
 * Answer pertanyaan dengan text natural language (NLP parsing)
 * Sistem akan parse text → determine yes/no
 */
export function answerQuestionWithText(sessionId, answerText) {
  return request(`/consultations/${sessionId}/answer-text`, {
    method: "POST",
    body: JSON.stringify({ answerText })
  });
}

export function fetchWhy(sessionId) {
  return request(`/consultations/${sessionId}/why`);
}

export function fetchHow(sessionId) {
  return request(`/consultations/${sessionId}/how`);
}

export function resetConsultation(sessionId) {
  return request(`/consultations/${sessionId}`, {
    method: "DELETE"
  });
}

/**
 * NLP: Extract gejala dari teks natural language
 */
export function extractSymptoms(text) {
  return request("/consultations/nlp/extract", {
    method: "POST",
    body: JSON.stringify({ text })
  });
}

/**
 * NLP: Start konsultasi langsung dari gejala
 */
export function startConsultationWithNLP(goalId, symptoms) {
  return request("/consultations/nlp/start", {
    method: "POST",
    body: JSON.stringify({ goalId, symptoms })
  });
}

/**
 * NLP: Auto-diagnose tanpa perlu pilih goal
 * User input gejala, sistem auto-detect goal dari gejala
 */
export function autoDiagnose(symptoms) {
  return request("/consultations/nlp/auto-diagnose", {
    method: "POST",
    body: JSON.stringify({ symptoms })
  });
}
