import { useEffect, useMemo, useState } from "react";
import {
  answerQuestion,
  answerQuestionWithText,
  autoDiagnose,
  fetchGoals,
  fetchHow,
  resetConsultation,
  startConsultation,
  startConsultationWithNLP
} from "../api/consultationApi.js";
import GoalSelector from "./GoalSelector.jsx";
import QuestionModal from "./QuestionModal.jsx";
import ResultModal from "./ResultModal.jsx";
import NLPInput from "./NLPInput.jsx";

const INITIAL_CONSULTATION = {
  sessionId: null,
  goal: null,
  question: null,
  result: null,
  workingMemory: [],
  how: []
};

function ConsultationContainer() {
  const [goals, setGoals] = useState([]);
  const [selectedGoalId, setSelectedGoalId] = useState("");
  const [consultation, setConsultation] = useState(INITIAL_CONSULTATION);
  const [isBootstrapping, setIsBootstrapping] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [nlpMode, setNlpMode] = useState(false); // false = not selected, true = modal, "input" = NLP input
  const [selectedGoal, setSelectedGoal] = useState(null);
  const [autoDiagnoseMode, setAutoDiagnoseMode] = useState(false); // For quick diagnosis without goal selection
  const [autoDiagnoseResults, setAutoDiagnoseResults] = useState(null); // All possible diagnoses for fallback

  useEffect(() => {
    let isActive = true;

    async function loadGoals() {
      try {
        const payload = await fetchGoals();
        if (isActive) {
          setGoals(payload.goals ?? []);
        }
      } catch (requestError) {
        if (isActive) {
          setError(requestError.message);
        }
      } finally {
        if (isActive) {
          setIsBootstrapping(false);
        }
      }
    }

    loadGoals();

    return () => {
      isActive = false;
    };
  }, []);

  async function handleStartConsultation(goalId) {
    setSelectedGoalId(goalId);
    setSelectedGoal(goals.find(g => g.id === goalId));
    setNlpMode(true); // Show mode selection
  }

  async function handleStartClassicMode(goalId) {
    setError("");
    setIsSubmitting(true);
    setNlpMode(false);

    try {
      const payload = await startConsultation(goalId);
      setConsultation({
        sessionId: payload.sessionId,
        goal: payload.goal,
        question: payload.question,
        result: payload.result,
        workingMemory: payload.workingMemory ?? [],
        how: payload.how ?? []
      });
    } catch (requestError) {
      setError(requestError.message);
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleStartNLPMode(symptoms) {
    setError("");
    setIsSubmitting(true);

    try {
      const payload = await startConsultationWithNLP(selectedGoalId, symptoms.symptoms);
      setConsultation({
        sessionId: payload.sessionId,
        goal: payload.goal,
        question: payload.question,
        result: payload.result,
        workingMemory: payload.workingMemory ?? [],
        how: payload.how ?? []
      });
      setNlpMode(false);
    } catch (requestError) {
      setError(requestError.message);
    } finally {
      setIsSubmitting(false);
    }
  }

  function handleCancelNLP() {
    setNlpMode(false);
    setSelectedGoalId("");
    setSelectedGoal(null);
  }

  async function handleAutoDiagnose(symptoms) {
    setError("");
    setIsSubmitting(true);

    try {
      const result = await autoDiagnose(symptoms.symptoms);
      
      // Store all results for fallback if needed
      setAutoDiagnoseResults(result);
      
      // Langsung set consultation dengan top diagnosis (paling memungkinkan)
      if (result.topDiagnosis) {
        setConsultation({
          sessionId: result.topDiagnosis.sessionId,
          goal: result.topDiagnosis.goal,
          question: result.topDiagnosis.question,
          result: result.topDiagnosis.result,
          workingMemory: result.topDiagnosis.workingMemory ?? [],
          how: []
        });
      }
      
      // Close input modal
      setAutoDiagnoseMode(false);
      
    } catch (requestError) {
      setError(requestError.message);
    } finally {
      setIsSubmitting(false);
    }
  }

  function handleCancelAutoDiagnose() {
    setAutoDiagnoseMode(false);
    setAutoDiagnoseResults(null);
  }

  async function handleAnswer(factId, value) {
    if (!consultation.sessionId) {
      return;
    }

    setError("");
    setIsSubmitting(true);

    try {
      let payload;
      
      // Check jika value adalah text (string) atau boolean
      if (typeof value === 'string') {
        // Text answer - gunakan NLP parsing
        payload = await answerQuestionWithText(consultation.sessionId, value);
      } else {
        // Boolean answer - gunakan API regular
        payload = await answerQuestion(consultation.sessionId, factId, value);
      }
      
      setConsultation((previous) => ({
        ...previous,
        goal: payload.goal,
        question: payload.question,
        result: payload.result,
        workingMemory: payload.workingMemory ?? [],
        how: payload.how ?? previous.how
      }));
    } catch (requestError) {
      setError(requestError.message);
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleRestart() {
    if (consultation.sessionId) {
      try {
        await resetConsultation(consultation.sessionId);
      } catch (requestError) {
        setError(requestError.message);
      }
    }

    setSelectedGoalId("");
    setSelectedGoal(null);
    setNlpMode(false);
    setAutoDiagnoseMode(false);
    setAutoDiagnoseResults(null);
    setConsultation(INITIAL_CONSULTATION);
  }

  const knownFacts = useMemo(
    () => consultation.workingMemory.filter((fact) => fact.source === "user"),
    [consultation.workingMemory]
  );

  return (
    <main className="app-shell">
      <section className="masthead">
        <div className="masthead__copy">
          <span className="eyebrow">🏥 Sistem Diagnosis Motor Matic</span>
          <h1>Konsultasi Masalah Motor Anda dengan Mudah</h1>
          <p>
            Sistem ini dirancang khusus untuk membantu Anda mengidentifikasi masalah motor matic dengan cara yang mudah dipahami. Cukup pilih gejala yang Anda rasakan, dan biarkan sistem menganalisis kemungkinan penyebabnya.
          </p>
          <div className="signal-row">
            <span className="signal-pill">💬 Interface Mudah Dimengerti</span>
            <span className="signal-pill">🔍 Analisis Otomatis</span>
            <span className="signal-pill">📋 Hasil Pasti</span>
          </div>
          <button
            className="quick-diagnose-btn"
            onClick={() => setAutoDiagnoseMode(true)}
            disabled={isBootstrapping || isSubmitting || consultation.sessionId}
          >
            ⚡ Diagnosis Cepat
          </button>
        </div>
        <aside className="panel panel--dark masthead__panel">
          <span className="eyebrow eyebrow--light">Status Sistem</span>
          <div className="metric-list">
            <article className="metric-card">
              <span>Hipotesis Diagnosis</span>
              <strong>{String(goals.length).padStart(2, "0")}</strong>
              <small>tersedia untuk dianalisis</small>
            </article>
            <article className="metric-card">
              <span>Gejala Tercatat</span>
              <strong>{String(knownFacts.length).padStart(2, "0")}</strong>
              <small>yang sudah Anda laporkan</small>
            </article>
            <article className="metric-card">
              <span>Status Analisis</span>
              <strong>{consultation.result ? (consultation.result.proven ? "✓ SELESAI" : "⚠ UNCLEAR") : "○ BERJALAN"}</strong>
              <small>{consultation.result ? "diagnosis selesai" : "menunggu input"}</small>
            </article>
          </div>
        </aside>
      </section>

      <section className="overview-grid">
        <article className="overview-card">
          <span className="overview-card__label">📋 Pilih Gejala</span>
          <strong>Mulai dari masalah yang Anda alami</strong>
          <p>Pilih gejala atau keluhan motor Anda, sistem akan mengajukan pertanyaan untuk memperdalam diagnosis.</p>
        </article>
        <article className="overview-card">
          <span className="overview-card__label">❓ Jawab Pertanyaan</span>
          <strong>Mudah dan cepat</strong>
          <p>Sistem mengajukan pertanyaan sederhana yang dapat dijawab "Ya" atau "Tidak" saja.</p>
        </article>
        <article className="overview-card">
          <span className="overview-card__label">✓ Dapatkan Hasil</span>
          <strong>Diagnosis yang akurat</strong>
          <p>Setelah cukup informasi, sistem akan memberikan diagnosis pasti dan rekomendasi tindakan.</p>
        </article>
      </section>

      <GoalSelector
        goals={goals}
        isLoading={isBootstrapping || isSubmitting}
        selectedGoalId={selectedGoalId}
        onSelectGoal={handleStartConsultation}
      />

      {nlpMode === true && selectedGoal && (
        <section className="mode-selection-container">
          <div className="mode-selection-panel">
            <h2>Pilih Cara Konsultasi</h2>
            <p>Anda memilih untuk mendiagnosa: <strong>{selectedGoal.label}</strong></p>

            <div className="mode-grid">
              <button
                className="mode-card mode-classic"
                onClick={() => handleStartClassicMode(selectedGoalId)}
                disabled={isSubmitting}
              >
                <div className="mode-icon">❓</div>
                <h3>Mode Cepat</h3>
                <p>Jawab pertanyaan Ya/Tidak</p>
                <span className="mode-desc">Sistem akan bertanya gejala satu per satu dengan format pilihan yang jelas.</span>
              </button>

              <button
                className="mode-card mode-nlp"
                onClick={() => setNlpMode("input")}
                disabled={isSubmitting}
              >
                <div className="mode-icon">🎙️</div>
                <h3>Input Manual</h3>
                <p>Deskripsikan dengan bahasa alami</p>
                <span className="mode-desc">Jelaskan gejala motor Anda dengan bebas, AI akan menganalisis dan mengekstrak gejala-gejalanya.</span>
              </button>
            </div>

            <button
              className="mode-back-btn"
              onClick={handleCancelNLP}
              disabled={isSubmitting}
            >
              ← Kembali
            </button>
          </div>
        </section>
      )}

      {nlpMode === "input" && selectedGoal && (
        <NLPInput
          goal={selectedGoal}
          onExtractedSymptoms={handleStartNLPMode}
          onCancel={handleCancelNLP}
        />
      )}

      {autoDiagnoseMode && (
        <NLPInput
          goal={null}
          isAutoMode={true}
          onExtractedSymptoms={handleAutoDiagnose}
          onCancel={handleCancelAutoDiagnose}
        />
      )}

      {error && (
        <div className="panel error-banner">
          <strong>⚠️ Error:</strong> {error}
        </div>
      )}

      {consultation.goal && (
        <section className="consultation-status">
          <div className="status-badge">
            <h3>Analisis: {consultation.goal.label}</h3>
            <p>{consultation.goal.description}</p>
            {autoDiagnoseResults && (
              <div className="auto-diagnosis-info">
                <small>🔍 Auto-diagnosis dari Diagnosis Cepat - Sistem memilih diagnosa dengan kemungkinan tertinggi</small>
              </div>
            )}
            {knownFacts.length > 0 && (
              <div className="known-facts">
                <strong>Gejala yang sudah Anda laporkan:</strong>
                <div className="fact-chips">
                  {knownFacts.map((fact) => (
                    <span key={fact.factId} className="fact-chip">
                      {fact.label}: {fact.value ? "✓ Ya" : "✗ Tidak"}
                    </span>
                  ))}
                </div>
              </div>
            )}
            {autoDiagnoseResults && autoDiagnoseResults.diagnosticResults && autoDiagnoseResults.diagnosticResults.length > 1 && (
              <details className="alt-diagnoses-details">
                <summary>💡 Coba diagnosis lain</summary>
                <div className="alt-diagnoses-list">
                  {autoDiagnoseResults.diagnosticResults
                    .filter(d => d.goal.id !== consultation.goal.id)
                    .map((diagnosis) => (
                      <button
                        key={diagnosis.goal.id}
                        className="alt-diagnosis-btn"
                        onClick={() => {
                          if (consultation.sessionId) {
                            resetConsultation(consultation.sessionId).catch(e => setError(e.message));
                          }
                          setConsultation({
                            sessionId: diagnosis.sessionId,
                            goal: diagnosis.goal,
                            question: diagnosis.question,
                            result: diagnosis.result,
                            workingMemory: diagnosis.workingMemory ?? [],
                            how: []
                          });
                        }}
                        disabled={isSubmitting}
                      >
                        {diagnosis.goal.label}
                        {diagnosis.result && diagnosis.result.proven && <span className="badge">✓</span>}
                      </button>
                    ))}
                </div>
              </details>
            )}
          </div>
        </section>
      )}

      <QuestionModal
        question={consultation.question}
        onAnswer={handleAnswer}
        isSubmitting={isSubmitting}
        goalLabel={consultation.goal?.label || ""}
      />

      <ResultModal
        result={consultation.result}
        onRestart={handleRestart}
        consultation={consultation}
      />
    </main>
  );
}

export default ConsultationContainer;
