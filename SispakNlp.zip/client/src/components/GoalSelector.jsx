function GoalSelector({ goals, isLoading, selectedGoalId, onSelectGoal }) {
  return (
    <section className="panel selector-panel">
      <div className="section-heading section-heading--split">
        <div>
          <span className="eyebrow">Goal-Driven Consultation</span>
          <h2>Pilih dugaan kerusakan yang ingin dibuktikan</h2>
          <p>
            Setiap kartu di bawah ini mewakili hipotesis awal. Pilih satu yang paling mendekati
            kondisi kendaraan agar sistem mulai menelusuri gejala pendukungnya.
          </p>
        </div>
        <div className="section-chip">
          <strong>{String(goals.length).padStart(2, "0")}</strong>
          <span>hipotesis tersedia</span>
        </div>
      </div>

      <div className="goal-grid">
        {goals.map((goal, index) => (
          <button
            key={goal.id}
            type="button"
            className={`goal-card ${selectedGoalId === goal.id ? "is-selected" : ""}`}
            onClick={() => onSelectGoal(goal.id)}
            disabled={isLoading}
          >
            <div className="goal-card__top">
              <span className="goal-card__index">{String(index + 1).padStart(2, "0")}</span>
              <span className="goal-card__badge">{goal.category}</span>
            </div>
            <div className="goal-card__body">
              <strong>{goal.label}</strong>
              <p>{goal.description}</p>
            </div>
            <div className="goal-card__footer">
              <small>{goal.recommendation}</small>
              <span className="goal-card__action">
                {selectedGoalId === goal.id ? "Hipotesis dipilih" : "Mulai analisis"}
              </span>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
}

export default GoalSelector;
