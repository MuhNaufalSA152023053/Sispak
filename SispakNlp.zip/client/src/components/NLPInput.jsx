import { useState } from "react";
import { extractSymptoms } from "../api/consultationApi.js";
import "../styles/nlp-input.css";

/**
 * NLPInput Component
 * 
 * Allows user to describe symptoms in natural language
 * Shows extracted symptoms and lets them proceed to diagnosis
 * 
 * Props:
 * - goal: Goal object (null for auto-diagnose mode)
 * - isAutoMode: Boolean to indicate quick diagnosis mode
 * - onExtractedSymptoms: Callback with extracted data
 * - onCancel: Callback when user cancels
 */
function NLPInput({ goal, isAutoMode = false, onExtractedSymptoms, onCancel }) {
  const [symptomText, setSymptomText] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [extractedSymptoms, setExtractedSymptoms] = useState([]);
  const [showExtracted, setShowExtracted] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false); // For proceed button
  const [error, setError] = useState("");

  const handleAnalyze = async () => {
    setError("");
    
    if (!symptomText.trim()) {
      setError("Mohon jelaskan gejala motor Anda.");
      return;
    }

    setIsAnalyzing(true);

    try {
      const result = await extractSymptoms(symptomText);
      setExtractedSymptoms(result.extracted);
      setShowExtracted(true);

      if (result.totalExtracted === 0) {
        setError("Tidak ada gejala yang terdeteksi. Coba deskripsikan dengan lebih detail.");
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleProceed = async () => {
    // Immediately send to parent - for auto-diagnose mode this triggers the API call
    setIsProcessing(true);
    try {
      onExtractedSymptoms({
        symptoms: symptomText,
        extractedList: extractedSymptoms
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && e.ctrlKey) {
      handleAnalyze();
    }
  };

  return (
    <div className="nlp-input-container">
      <div className="nlp-input-panel">
        <div className="nlp-input-header">
          {isAutoMode ? (
            <>
              <h3>⚡ Diagnosis Cepat - Deskripsikan Gejala</h3>
              <p>Jelaskan semua gejala yang Anda alami. Sistem akan menganalisis dan mencari semua kemungkinan diagnosis.</p>
            </>
          ) : (
            <>
              <h3>🎙️ Mode NLP - Deskripsikan Gejala</h3>
              <p>Jelaskan keluhan motor Anda dengan bahasa alami. AI akan menganalisis dan mengekstrak gejala-gejalanya.</p>
            </>
          )}
        </div>

        <div className="nlp-input-section">
          <textarea
            className="nlp-textarea"
            placeholder="Contoh: Motor saya panas dan gredek saat dihidupkan, sudah lama tidak dirawat, ada noda minyak di bawahnya..."
            value={symptomText}
            onChange={(e) => setSymptomText(e.target.value)}
            onKeyPress={handleKeyPress}
            disabled={isAnalyzing || showExtracted}
            rows={5}
          />

          <div className="nlp-button-group">
            <button
              className="nlp-analyze-btn"
              onClick={handleAnalyze}
              disabled={isAnalyzing || !symptomText.trim() || showExtracted}
            >
              {isAnalyzing ? "🔍 Menganalisis..." : "🔍 Analisis Gejala"}
            </button>
            <button
              className="nlp-cancel-btn"
              onClick={onCancel}
              disabled={isAnalyzing}
            >
              ✕ Kembali
            </button>
          </div>

          {error && <div className="nlp-error">{error}</div>}
        </div>

        {showExtracted && extractedSymptoms.length > 0 && (
          <div className="nlp-extracted-section">
            <h4>✓ Gejala Terdeteksi ({extractedSymptoms.length})</h4>
            <div className="nlp-symptoms-list">
              {extractedSymptoms.map((symptom, idx) => (
                <div key={idx} className="nlp-symptom-item">
                  <div className="nlp-symptom-header">
                    <span className="nlp-symptom-label">{symptom.label}</span>
                    <span className="nlp-confidence">
                      {symptom.confidence}% match
                    </span>
                  </div>
                  <p className="nlp-symptom-desc">{symptom.description}</p>
                  <span className="nlp-keyword">Kata kunci: "{symptom.matchedKeyword}"</span>
                </div>
              ))}
            </div>

            <div className="nlp-action-group">
              <button
                className="nlp-proceed-btn"
                onClick={handleProceed}
                autoFocus
                disabled={isAnalyzing || isProcessing}
              >
                {isProcessing ? "⏳ Memproses Diagnosis..." : 
                  isAutoMode
                    ? `🚀 Mulai Diagnosis (${extractedSymptoms.length} Gejala)`
                    : `✓ Lanjut Diagnosa dengan ${extractedSymptoms.length} Gejala`}
              </button>
              <button
                className="nlp-retry-btn"
                onClick={() => {
                  setShowExtracted(false);
                  setExtractedSymptoms([]);
                }}
              >
                ↻ Ubah Deskripsi
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default NLPInput;
