const ANSWERS = [
  { label: "Ya", value: true, note: "Premis diterima" },
  { label: "Tidak", value: false, note: "Premis ditolak" }
];

function QuestionCard({ question, onAnswer, onToggleWhy, showWhy, isSubmitting }) {
  if (!question) {
    return null;
  }

  return (
    <section className="panel question-panel">
      <div className="question-panel__header">
        <div>
          <span className="eyebrow">Pertanyaan Aktif</span>
          <h3>{question.prompt}</h3>
          <div className="question-inline-note">
            <span>Fakta yang diverifikasi</span>
            <strong>{question.label}</strong>
          </div>
        </div>
        <button type="button" className="link-button" onClick={onToggleWhy}>
          {showWhy ? "Sembunyikan Mengapa?" : "Mengapa?"}
        </button>
      </div>

      <p className="question-hint">{question.hint}</p>

      {showWhy && question.why && (
        <div className="explanation-box">
          <strong>{question.why.title}</strong>
          <p>{question.why.summary}</p>
          <ul className="detail-list">
            <li>Hipotesis aktif: {question.why.goalLabel}</li>
            <li>Aturan: {question.why.ruleLabel}</li>
            <li>Fakta belum terverifikasi: {question.why.missingFactLabel}</li>
            <li>Jalur DFS: {question.why.path.join(" → ")}</li>
          </ul>
        </div>
      )}

      <div className="answer-grid">
        {ANSWERS.map((answer) => (
          <button
            key={answer.label}
            type="button"
            className={`answer-button ${answer.value ? "is-affirmative" : "is-negative"}`}
            onClick={() => onAnswer(question.factId, answer.value)}
            disabled={isSubmitting}
          >
            <span>{answer.label}</span>
            <small>{answer.note}</small>
          </button>
        ))}
      </div>
    </section>
  );
}

export default QuestionCard;
