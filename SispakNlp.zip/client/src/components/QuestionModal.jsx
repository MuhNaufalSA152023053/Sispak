import { useState } from "react";
import "../styles/modal.css";

function QuestionModal({ question, onAnswer, isSubmitting, goalLabel }) {
  const [showWhy, setShowWhy] = useState(false);
  const [answerText, setAnswerText] = useState("");

  if (!question) {
    return null;
  }

  const handleSubmit = () => {
    if (answerText.trim().length === 0) {
      alert("Silakan isi jawaban Anda");
      return;
    }
    onAnswer(question.factId, answerText.trim());
    setAnswerText("");
    setShowWhy(false);
  };

  const handleClose = () => {
    if (!isSubmitting) {
      setShowWhy(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && e.ctrlKey) {
      handleSubmit();
    }
  };

  return (
    <div className="modal-overlay modal-overlay--active">
      <div className="modal modal--question">
        <div className="modal-header">
          <h2>
            <i className="fas fa-circle-question"></i>
            Pertanyaan
          </h2>
          <button
            type="button"
            className="modal-close"
            onClick={handleClose}
            aria-label="Close"
            disabled={isSubmitting}
            title="Tutup pertanyaan"
          >
            <i className="fas fa-times"></i>
          </button>
        </div>

        <div className="modal-body">
          <div className="question-context">
            <p className="question-context__goal">
              <i className="fas fa-wrench"></i>
              <strong>Diagnosa:</strong> {goalLabel}
            </p>
          </div>

          <div className="question-main">
            <p className="question-prompt">{question.prompt}</p>
            {question.hint && (
              <div className="question-hint">
                <i className="fas fa-lightbulb"></i>
                <span>{question.hint}</span>
              </div>
            )}
          </div>

          {showWhy && question.why && (
            <div className="question-why">
              <strong>
                <i className="fas fa-info-circle"></i>
                {question.why.title}
              </strong>
              <p>{question.why.summary}</p>
              <details className="why-details">
                <summary>
                  <i className="fas fa-chevron-down"></i>
                  Detail pemeriksaan
                </summary>
                <ul className="detail-list">
                  <li>
                    <strong>Hipotesis:</strong> {question.why.goalLabel}
                  </li>
                  <li>
                    <strong>Aturan:</strong> {question.why.ruleLabel}
                  </li>
                  <li>
                    <strong>Fakta:</strong> {question.why.missingFactLabel}
                  </li>
                  <li>
                    <strong>Jalur analisis:</strong> {question.why.path.join(" → ")}
                  </li>
                </ul>
              </details>
            </div>
          )}

          <div className="question-answer-section">
            <label className="answer-label">
              <i className="fas fa-pen"></i>
              Jawaban Anda:
            </label>
            <textarea
              className="answer-textarea"
              value={answerText}
              onChange={(e) => setAnswerText(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Deskripsikan jawaban Anda dengan bebas... (Ctrl+Enter untuk submit)"
              disabled={isSubmitting}
              rows="4"
            />
            <div className="answer-hint-text">
              💡 Tulis apa yang Anda alami. Sistem akan menganalisis jawaban Anda.
            </div>
          </div>
        </div>

        <div className="modal-footer modal-footer--question">
          <button
            type="button"
            className="why-button"
            onClick={() => setShowWhy(!showWhy)}
            disabled={isSubmitting}
          >
            <i className={`fas fa-${showWhy ? "eye-slash" : "eye"}`}></i>
            {showWhy ? "Tutup" : "Mengapa?"}
          </button>

          <button
            type="button"
            className="answer-button answer-button--submit"
            onClick={handleSubmit}
            disabled={isSubmitting || answerText.trim().length === 0}
          >
            <i className="fas fa-arrow-right"></i>
            {isSubmitting ? "⏳ Memproses..." : "Lanjut"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default QuestionModal;
