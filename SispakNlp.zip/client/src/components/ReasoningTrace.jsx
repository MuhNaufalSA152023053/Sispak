function ReasoningTrace({ steps, isVisible, onToggle }) {
  if (!steps?.length) {
    return null;
  }

  return (
    <section className="panel trace-panel">
      <div className="question-panel__header">
        <div>
          <span className="eyebrow">Explanation Facility</span>
          <h3>Bagaimana sistem mengambil keputusan?</h3>
          <p className="trace-intro">
            Ringkasan ini memperlihatkan urutan pemikiran sistem dari goal utama hingga aturan yang
            akhirnya terpenuhi.
          </p>
        </div>
        <div className="trace-panel__actions">
          <span className="trace-count">{steps.length} langkah</span>
          <button type="button" className="link-button" onClick={onToggle}>
            {isVisible ? "Tutup Bagaimana?" : "Bagaimana?"}
          </button>
        </div>
      </div>

      {isVisible && (
        <ol className="trace-list">
          {steps.map((step, index) => (
            <li key={`${step}-${index}`} className="trace-item">
              <span className="trace-index">{String(index + 1).padStart(2, "0")}</span>
              <p>{step}</p>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}

export default ReasoningTrace;
