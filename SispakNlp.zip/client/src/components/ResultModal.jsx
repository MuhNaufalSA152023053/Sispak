import "../styles/modal.css";

function ResultModal({ result, onRestart, consultation }) {
  if (!result) {
    return null;
  }

  const statusIcon = result.proven ? "fa-check-circle" : "fa-times-circle";
  const statusColor = result.proven ? "is-success" : "is-danger";

  return (
    <div className="modal-overlay modal-overlay--active">
      <div className={`modal modal--result ${statusColor}`}>
        <div className="modal-header">
          <h2>
            <i className={`fas ${statusIcon}`}></i>
            Hasil Diagnosis
          </h2>
        </div>

        <div className="modal-body">
          <div className={`result-status ${statusColor}`}>
            <div className="status-icon">
              <i className={`fas fa-2x ${statusIcon}`}></i>
            </div>
            <div className="status-text">
              <h3>{result.title}</h3>
              <p className="diagnosis-name">{result.goalLabel}</p>
            </div>
          </div>

          <div className="result-summary">
            {result.summary}
          </div>

          <div className="result-details">
            <div className="detail-section">
              <h4>
                <i className="fas fa-motorcycle"></i>
                Diagnosis
              </h4>
              <p>{result.goalLabel}</p>
            </div>

            <div className="detail-section">
              <h4>
                <i className="fas fa-gavel"></i>
                Verifikasi Sistem
              </h4>
              <p>
                {result.proven
                  ? "✓ Diagnosis TERBUKTI berdasarkan gejala yang Anda laporkan"
                  : "✗ Diagnosis tidak dapat dipastikan dengan gejala yang ada"}
              </p>
            </div>

            <div className="detail-section">
              <h4>
                <i className="fas fa-tools"></i>
                Rekomendasi Tindakan
              </h4>
              <p>{result.recommendation}</p>
            </div>

            {consultation.how && consultation.how.length > 0 && (
              <div className="detail-section">
                <h4>
                  <i className="fas fa-shoe-prints"></i>
                  Jejak Analisis Sistem
                </h4>
                <div className="reasoning-trace">
                  {consultation.how.slice(0, 5).map((step, idx) => (
                    <p key={idx} className="trace-step">
                      {step}
                    </p>
                  ))}
                  {consultation.how.length > 5 && (
                    <p className="trace-more">
                      <i className="fas fa-ellipsis-h"></i>
                      dan {consultation.how.length - 5} langkah lainnya
                    </p>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="modal-footer">
          <button
            type="button"
            className="restart-button"
            onClick={onRestart}
          >
            <i className="fas fa-redo"></i>
            Konsultasi Baru
          </button>
        </div>
      </div>
    </div>
  );
}

export default ResultModal;
