function ResultPanel({ result, onRestart }) {
  if (!result) {
    return null;
  }

  return (
    <section className={`panel result-panel ${result.proven ? "is-proven" : "is-unproven"}`}>
      <div className="section-heading section-heading--split">
        <div>
          <span className="eyebrow">Hasil Diagnosa</span>
          <h2>{result.title}</h2>
          <p>{result.summary}</p>
        </div>
        <div className="result-badge">
          <span>Status</span>
          <strong>{result.proven ? "✓ PASTI" : "✗ TIDAK PASTI"}</strong>
        </div>
      </div>

      <div className="result-grid">
        <article className="result-card">
          <span>Diagnosa</span>
          <strong>{result.goalLabel}</strong>
        </article>
        <article className="result-card">
          <span>Hasil Verifikasi</span>
          <strong>{result.proven ? "✓ TERBUKTI" : "✗ TIDAK TERBUKTI"}</strong>
        </article>
      </div>

      <div className="result-recommendation">
        <strong>Rekomendasi Tindak Lanjut</strong>
        <p>{result.recommendation}</p>
      </div>

      <button type="button" className="primary-button" onClick={onRestart}>
        Mulai konsultasi baru
      </button>
    </section>
  );
}

export default ResultPanel;
