import cors from "cors";
import express from "express";
import consultationRoutes from "./routes/consultationRoutes.js";

const app = express();

app.use(
  cors({
    origin: function(origin, callback) {
      // Allow all localhost variations (5173, 5174, 3000, etc)
      if (!origin || /^http:\/\/localhost(:\d+)?$/.test(origin)) {
        callback(null, true);
      } else {
        callback(new Error('CORS not allowed for origin: ' + origin));
      }
    }
  })
);
app.use(express.json());

app.get("/api/health", (_request, response) => {
  response.json({
    status: "ok",
    service: "automotive-expert-system"
  });
});

app.use("/api", consultationRoutes);

app.use((error, _request, response, _next) => {
  console.error(error);
  response.status(500).json({
    error: "Terjadi kegagalan internal pada server inferensi."
  });
});

export default app;
