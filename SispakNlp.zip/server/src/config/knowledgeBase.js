import fs from "node:fs";

const knowledgeBasePath = new URL("../data/rules.json", import.meta.url);
const rawKnowledgeBase = JSON.parse(fs.readFileSync(knowledgeBasePath, "utf-8"));

function assertUnique(items, label) {
  const seen = new Set();

  for (const item of items) {
    if (seen.has(item.id)) {
      throw new Error(`Duplikasi ${label} dengan id "${item.id}" pada rules.json`);
    }

    seen.add(item.id);
  }
}

assertUnique(rawKnowledgeBase.goals, "goal");
assertUnique(rawKnowledgeBase.facts, "fact");
assertUnique(rawKnowledgeBase.rules, "rule");

const goalsById = new Map(rawKnowledgeBase.goals.map((goal) => [goal.id, goal]));
const factsById = new Map(rawKnowledgeBase.facts.map((fact) => [fact.id, fact]));
const rulesByConclusion = rawKnowledgeBase.rules.reduce((map, rule) => {
  const bucket = map.get(rule.conclusion) ?? [];
  bucket.push(rule);
  bucket.sort((left, right) => (left.priority ?? 999) - (right.priority ?? 999));
  map.set(rule.conclusion, bucket);
  return map;
}, new Map());

function getLabel(symbolId) {
  return goalsById.get(symbolId)?.label ?? factsById.get(symbolId)?.label ?? symbolId;
}

export const knowledgeBase = {
  ...rawKnowledgeBase,
  goalsById,
  factsById,
  rulesByConclusion,
  getLabel
};
