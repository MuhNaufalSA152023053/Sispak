import express from "express";
import { knowledgeBase } from "../config/knowledgeBase.js";
import InferenceEngine from "../services/inferenceEngine.js";
import SessionStore from "../services/sessionStore.js";
import NLPService from "../services/nlpService.js";

const router = express.Router();
const sessionStore = new SessionStore({
  ttlMinutes: Number(process.env.SESSION_TTL_MINUTES ?? 30)
});
const inferenceEngine = new InferenceEngine(knowledgeBase);
const nlpService = new NLPService(knowledgeBase);

function getSessionOrFail(sessionId, response) {
  const session = sessionStore.get(sessionId);

  if (!session) {
    response.status(404).json({
      error: "Sesi konsultasi tidak ditemukan atau sudah kedaluwarsa."
    });
    return null;
  }

  sessionStore.touch(session);
  return session;
}

router.get("/goals", (_request, response) => {
  response.json({
    metadata: knowledgeBase.metadata,
    goals: knowledgeBase.goals
  });
});

router.post("/consultations/start", (request, response) => {
  const { goalId } = request.body ?? {};

  if (!goalId || !knowledgeBase.goalsById.has(goalId)) {
    return response.status(400).json({
      error: "Goal tidak valid. Pilih salah satu dugaan kerusakan yang tersedia."
    });
  }

  const session = sessionStore.create(goalId);
  const payload = inferenceEngine.evaluate(session);

  return response.status(201).json(payload);
});

router.post("/consultations/:sessionId/answer", (request, response) => {
  const session = getSessionOrFail(request.params.sessionId, response);

  if (!session) {
    return undefined;
  }

  const { factId, value } = request.body ?? {};

  if (!session.currentQuestion) {
    return response.status(409).json({
      error: "Tidak ada pertanyaan aktif untuk sesi ini."
    });
  }

  if (factId !== session.currentQuestion.factId) {
    return response.status(409).json({
      error: "Jawaban tidak cocok dengan pertanyaan aktif."
    });
  }

  if (!knowledgeBase.factsById.has(factId)) {
    return response.status(400).json({
      error: "Fakta yang dikirim tidak dikenal oleh knowledge base."
    });
  }

  if (typeof value !== "boolean") {
    return response.status(400).json({
      error: "Nilai jawaban harus boolean (true atau false)."
    });
  }

  sessionStore.recordUserFact(session, factId, value);
  const payload = inferenceEngine.evaluate(session);

  return response.json(payload);
});

router.get("/consultations/:sessionId/why", (request, response) => {
  const session = getSessionOrFail(request.params.sessionId, response);

  if (!session) {
    return undefined;
  }

  if (!session.currentQuestion?.why) {
    return response.status(404).json({
      error: "Belum ada penjelasan aktif karena sesi tidak sedang menunggu jawaban."
    });
  }

  return response.json({
    sessionId: session.id,
    why: session.currentQuestion.why
  });
});

router.get("/consultations/:sessionId/how", (request, response) => {
  const session = getSessionOrFail(request.params.sessionId, response);

  if (!session) {
    return undefined;
  }

  return response.json({
    sessionId: session.id,
    how: session.reasoningLog,
    trace: session.trace
  });
});

router.delete("/consultations/:sessionId", (request, response) => {
  sessionStore.delete(request.params.sessionId);

  return response.json({
    message: "Sesi konsultasi dihapus."
  });
});

/**
 * Endpoint NLP: Extract gejala dari teks natural language
 * POST /api/consultations/nlp/extract
 * Body: {text: "Motor saya panas dan gredek"}
 * Response: {symptoms: [{factId, label, confidence}], totalExtracted}
 */
router.post("/consultations/nlp/extract", (request, response) => {
  const { text } = request.body ?? {};

  if (!text || typeof text !== "string" || text.trim().length === 0) {
    return response.status(400).json({
      error: "Deskripsi gejala tidak boleh kosong. Jelaskan keluhan motor Anda dengan bahasa alami."
    });
  }

  try {
    const result = nlpService.extractSymptoms(text);
    
    return response.json({
      extracted: result.symptoms.map(symptom => ({
        factId: symptom.factId,
        label: symptom.fact.label,
        description: symptom.fact.question,
        matchedKeyword: symptom.matchedKeyword,
        confidence: Math.min(Math.round((symptom.score / 5) * 100), 100)
      })),
      totalExtracted: result.symptoms.length,
      raw: text
    });
  } catch (error) {
    console.error("NLP extraction error:", error);
    return response.status(500).json({
      error: "Gagal menganalisis gejala Anda."
    });
  }
});

/**
 * Endpoint NLP: Start konsultasi langsung dari deskripsi gejala
 * POST /api/consultations/nlp/start
 * Body: {goalId: "mesin_mati_total", symptoms: "Motor tidak hidup dan aki mati"}
 * Response: Sama seperti /start, tapi sudah pre-filled dengan facts dari NLP
 */
router.post("/consultations/nlp/start", (request, response) => {
  const { goalId, symptoms: symptomText } = request.body ?? {};

  // Validate goal
  if (!goalId || !knowledgeBase.goalsById.has(goalId)) {
    return response.status(400).json({
      error: "Goal tidak valid. Pilih salah satu dugaan kerusakan yang tersedia."
    });
  }

  // Validate symptom text
  if (!symptomText || typeof symptomText !== "string" || symptomText.trim().length === 0) {
    return response.status(400).json({
      error: "Deskripsi gejala tidak boleh kosong."
    });
  }

  try {
    // Extract symptoms dari teks
    const extractedData = nlpService.extractAsWorkingMemory(symptomText);

    // Create session
    const session = sessionStore.create(goalId);

    // Pre-fill working memory dengan extracted facts
    extractedData.extractedFacts.forEach(({ id: factId }) => {
      sessionStore.recordUserFact(session, factId, true);
    });

    // Evaluate inference engine
    const payload = inferenceEngine.evaluate(session);

    // Add NLP metadata
    return response.status(201).json({
      ...payload,
      nlpMetadata: {
        extractedFacts: extractedData.extractedFacts,
        totalExtracted: extractedData.totalExtracted,
        symptomInput: symptomText
      }
    });
  } catch (error) {
    console.error("NLP consultation start error:", error);
    return response.status(500).json({
      error: "Gagal memulai konsultasi NLP."
    });
  }
});

/**
 * Endpoint NLP: Auto-diagnose tanpa perlu pilih goal
 * POST /api/consultations/nlp/auto-diagnose
 * Body: {symptoms: "Motor panas gredek minyak keluar"}
 * Response: Langsung diagnosa untuk semua goal, return yang proven atau top candidates
 * 
 * User flow:
 * 1. Klik "Diagnosis Cepat"
 * 2. Input gejala
 * 3. Sistem auto-detect goal
 * 4. Langsung tampilkan hasil
 */
router.post("/consultations/nlp/auto-diagnose", (request, response) => {
  const { symptoms: symptomText } = request.body ?? {};

  if (!symptomText || typeof symptomText !== "string" || symptomText.trim().length === 0) {
    return response.status(400).json({
      error: "Deskripsi gejala tidak boleh kosong."
    });
  }

  try {
    // Extract symptoms dari teks user
    const extractedData = nlpService.extractAsWorkingMemory(symptomText);

    if (extractedData.totalExtracted === 0) {
      return response.status(400).json({
        error: "Tidak ada gejala yang terdeteksi. Coba deskripsikan dengan lebih detail.",
        extracted: []
      });
    }

    // Try setiap goal dengan gejala yang di-extract
    const diagnosticResults = [];

    for (const goal of knowledgeBase.goals) {
      try {
        // Create session untuk goal ini
        const session = sessionStore.create(goal.id);

        // Pre-fill dengan extracted facts
        extractedData.extractedFacts.forEach(({ id: factId }) => {
          sessionStore.recordUserFact(session, factId, true);
        });

        // Evaluate
        const payload = inferenceEngine.evaluate(session);

        // Store hasil
        diagnosticResults.push({
          goal: {
            id: goal.id,
            label: goal.label,
            category: goal.category,
            description: goal.description,
            recommendation: goal.recommendation
          },
          result: payload.result,
          sessionId: payload.sessionId,
          phase: payload.phase,
          proven: payload.result?.proven ?? false,
          question: payload.question, // Jika ada pertanyaan follow-up
          workingMemory: payload.workingMemory ?? []
        });
      } catch (goalError) {
        console.error(`Error evaluating goal ${goal.id}:`, goalError);
      }
    }

    // Sort: proven dulu, terus by confidence/summary
    diagnosticResults.sort((a, b) => {
      if (a.proven && !b.proven) return -1;
      if (!a.proven && b.proven) return 1;
      return 0;
    });

    // Return hasil
    return response.json({
      extractedFacts: extractedData.extractedFacts,
      totalExtracted: extractedData.totalExtracted,
      symptomInput: symptomText,
      diagnosticResults,
      totalResults: diagnosticResults.length,
      provenResults: diagnosticResults.filter(r => r.proven).length,
      // Helper: return top diagnosis (proven or first one)
      topDiagnosis: diagnosticResults[0] ?? null
    });
  } catch (error) {
    console.error("NLP auto-diagnose error:", error);
    return response.status(500).json({
      error: "Gagal melakukan diagnosis otomatis."
    });
  }
});

/**
 * Endpoint: Jawab pertanyaan dengan text alami (NLP parsing)
 * POST /api/consultations/:sessionId/answer-text
 * Body: {answerText: "Iya, starter tidak bunyi"}
 * Response: Sama seperti /answer, tapi value di-parse dari text
 * 
 * User flow:
 * 1. Sistem tampilkan pertanyaan
 * 2. User ketik jawaban bebas
 * 3. Klik "Lanjut"
 * 4. Backend parse → determine yes/no
 * 5. Process inference → next question atau result
 */
router.post("/consultations/:sessionId/answer-text", (request, response) => {
  const session = getSessionOrFail(request.params.sessionId, response);

  if (!session) {
    return undefined;
  }

  const { answerText } = request.body ?? {};

  if (!answerText || typeof answerText !== "string" || answerText.trim().length === 0) {
    return response.status(400).json({
      error: "Jawaban tidak boleh kosong. Jelaskan secara singkat."
    });
  }

  if (!session.currentQuestion) {
    return response.status(409).json({
      error: "Tidak ada pertanyaan aktif untuk sesi ini."
    });
  }

  try {
    // Parse text answer menggunakan NLP
    const parseResult = nlpService.parseAnswer(answerText.trim());
    
    // Record sebagai user fact dengan value yang sudah di-parse
    sessionStore.recordUserFact(
      session,
      session.currentQuestion.factId,
      parseResult.value
    );

    // Evaluate inference engine
    const payload = inferenceEngine.evaluate(session);

    // Return dengan tambahan NLP parsing info
    return response.json({
      ...payload,
      answerMetadata: {
        userInput: answerText,
        parsedValue: parseResult.value,
        confidence: parseResult.confidence,
        matchedKeywords: parseResult.matchedKeywords || []
      }
    });
  } catch (error) {
    console.error("Text answer parsing error:", error);
    return response.status(500).json({
      error: "Gagal memproses jawaban Anda. Coba lagi dengan deskripsi yang lebih jelas."
    });
  }
});

export default router;
