/**
 * InferenceEngine - Backward Chaining dengan DFS (Depth-First Search)
 * 
 * Algoritma:
 * 1. Mulai dari goal yang ingin dibuktikan
 * 2. Gunakan DFS untuk menjelajahi semua kemungkinan aturan
 * 3. Jika semua premise rule TERBUKTI, maka conclusion TERBUKTI
 * 4. Hasil: kepastian (PROVEN atau NOT_PROVEN)
 * 5. Tanpa Certainty Factor (CF) - hanya logika boolean
 */

class InferenceEngine {
  constructor(knowledgeBase) {
    this.knowledgeBase = knowledgeBase;
  }

  evaluate(session) {
    const context = {
      session,
      goalStack: [],
      ruleStack: [],
      trace: [],
      howSteps: []
    };

    session.currentQuestion = null;
    const outcome = this.prove(session.goalId, context);

    session.trace = context.trace;
    session.reasoningLog = context.howSteps;

    if (outcome.status === "question") {
      session.lastResult = null;
      return this.buildQuestionPayload(session, outcome.question);
    }

    const goal = this.knowledgeBase.goalsById.get(session.goalId);

    const result = {
      title: outcome.proven 
        ? "✓ Hipotesis TERBUKTI - Diagnosis Pasti"
        : "✗ Hipotesis TIDAK TERBUKTI - Tidak Ada Cukup Bukti",
      goalId: session.goalId,
      goalLabel: goal.label,
      proven: outcome.proven,
      summary: outcome.proven
        ? `Sistem MEMASTIKAN diagnosis: ${goal.label}\n\nBerdasarkan data dan aturan yang telah diverivikasi, motor Anda mengalami masalah tersebut.`
        : `Sistem TIDAK DAPAT memastikan diagnosis: ${goal.label}\n\nFakta dan bukti yang tersedia tidak mencukupi untuk menyimpulkan masalah ini.`,
      recommendation: goal.recommendation
    };

    session.lastResult = result;

    return {
      phase: "result",
      sessionId: session.id,
      goal,
      question: null,
      result,
      workingMemory: this.serializeWorkingMemory(session),
      how: session.reasoningLog
    };
  }

  /**
   * DFS-based proof algorithm untuk Backward Chaining
   * Mencoba membuktikan targetId dengan iterasi mendalam ke dalam aturan
   */
  prove(targetId, context) {
    const { session, goalStack, ruleStack, trace } = context;

    // Deteksi siklus untuk menghindari infinite loop
    if (goalStack.includes(targetId)) {
      trace.push({
        kind: "cycle-detected",
        targetId,
        path: this.toLabelPath(goalStack)
      });
      this.addHow(context, `⚠️ Siklus terdeteksi pada ${this.label(targetId)}, cabang dihentikan.`);
      return { status: "complete", proven: false };
    }

    goalStack.push(targetId);

    try {
      this.addHow(context, `🔍 Membuktikan: ${this.label(targetId)}`);
      trace.push({
        kind: "goal-enter",
        targetId,
        path: this.toLabelPath(goalStack)
      });

      // Cek Working Memory (menyimpan hasil pembuktian sebelumnya)
      const known = session.workingMemory[targetId];
      if (known !== undefined) {
        trace.push({
          kind: "working-memory-hit",
          targetId,
          value: known.value,
          source: known.source,
          path: this.toLabelPath(goalStack)
        });

        const status = known.value ? "✓ Terbukti" : "✗ Terbantah";
        this.addHow(context, `${status}: ${this.label(targetId)} dari ${known.source}`);

        return {
          status: "complete",
          proven: known.value,
          source: known.source
        };
      }

      // Cek apakah ini fakta yang bisa ditanya ke user
      const askableFact = this.knowledgeBase.factsById.get(targetId);
      if (askableFact?.askable) {
        const question = this.buildQuestion(targetId, context);
        session.currentQuestion = question;

        trace.push({
          kind: "question-generated",
          targetId,
          question: question.prompt,
          path: this.toLabelPath(goalStack)
        });

        this.addHow(context, `❓ Tanya ke user: ${this.label(targetId)}`);
        return { status: "question", question };
      }

      // Cari semua aturan yang bisa menyimpulkan targetId
      const candidateRules = this.knowledgeBase.rulesByConclusion.get(targetId) ?? [];

      if (candidateRules.length === 0) {
        trace.push({
          kind: "no-rule",
          targetId,
          path: this.toLabelPath(goalStack)
        });
        this.addHow(context, `✗ Tidak ada aturan untuk membuktikan ${this.label(targetId)}.`);
        return { status: "complete", proven: false };
      }

      // DFS: Coba setiap aturan secara berurutan
      for (const rule of candidateRules) {
        ruleStack.push(rule);

        try {
          this.addHow(context, `📋 Uji aturan ${rule.id}: ${rule.premises.map(p => this.label(p)).join(" ∧ ")} ⟹ ${this.label(rule.conclusion)}`);

          trace.push({
            kind: "rule-enter",
            ruleId: rule.id,
            targetId,
            premises: rule.premises,
            path: this.toLabelPath(goalStack)
          });

          let allPremisesProven = true;
          let failedPremise = null;

          // Buktikan setiap premise dari aturan secara sekuensial (DFS)
          for (const premiseId of rule.premises) {
            const premiseResult = this.prove(premiseId, context);

            // Jika perlu tanya user, kembalikan pertanyaan
            if (premiseResult.status === "question") {
              trace.push({
                kind: "rule-paused",
                ruleId: rule.id,
                pendingPremise: premiseId,
                path: this.toLabelPath(goalStack)
              });
              return premiseResult;
            }

            // Jika premise tidak terbukti, aturan ini gagal
            if (!premiseResult.proven) {
              allPremisesProven = false;
              failedPremise = premiseId;
              this.addHow(context, `✗ Aturan ${rule.id} gagal: ${this.label(failedPremise)} tidak terbukti`);
              break;
            }
          }

          // Jika semua premise terbukti, aturan berhasil
          if (allPremisesProven) {
            session.workingMemory[targetId] = {
              value: true,
              source: "derived",
              ruleId: rule.id,
              updatedAt: new Date().toISOString()
            };

            trace.push({
              kind: "rule-satisfied",
              ruleId: rule.id,
              targetId,
              path: this.toLabelPath(goalStack)
            });

            this.addHow(context, `✓ Aturan ${rule.id} BERHASIL: ${this.label(targetId)} TERBUKTI`);
            return { status: "complete", proven: true, ruleId: rule.id };
          }
        } finally {
          ruleStack.pop();
        }
      }

      // Semua aturan telah dicoba, tidak ada yang berhasil
      this.addHow(context, `✗ Semua aturan untuk ${this.label(targetId)} telah dicoba, tidak ada yang terbukti.`);
      return { status: "complete", proven: false };
    } finally {
      goalStack.pop();
    }
  }

  buildQuestion(factId, context) {
    const fact = this.knowledgeBase.factsById.get(factId);
    const activeRule = context.ruleStack.at(-1);
    const goal = this.knowledgeBase.goalsById.get(context.session.goalId);

    return {
      factId,
      label: fact.label,
      prompt: fact.question,
      hint: fact.hint,
      why: {
        title: "Fakta ini diperlukan untuk melanjutkan pembuktian",
        summary: activeRule
          ? `Sistem sedang memverifikasi aturan ${activeRule.id} untuk mendukung hipotesis ${goal.label}.`
          : `Sistem membutuhkan fakta ini untuk memverifikasi hipotesis ${goal.label}.`,
        goalLabel: goal.label,
        ruleLabel: activeRule
          ? `${activeRule.id} - ${activeRule.explanation}`
          : "Verifikasi langsung terhadap hipotesis",
        missingFactLabel: fact.label,
        path: this.toLabelPath(context.goalStack)
      }
    };
  }

  buildQuestionPayload(session, question) {
    return {
      phase: "question",
      sessionId: session.id,
      goal: this.knowledgeBase.goalsById.get(session.goalId),
      question,
      result: null,
      workingMemory: this.serializeWorkingMemory(session),
      how: session.reasoningLog
    };
  }

  serializeWorkingMemory(session) {
    return Object.entries(session.workingMemory).map(([factId, entry]) => ({
      factId,
      label: this.label(factId),
      value: entry.value,
      source: entry.source,
      ruleId: entry.ruleId ?? null
    }));
  }

  label(symbolId) {
    return this.knowledgeBase.getLabel(symbolId);
  }

  toLabelPath(path) {
    return path.map((symbolId) => this.label(symbolId));
  }

  addHow(context, message) {
    const previous = context.howSteps.at(-1);
    if (previous !== message) {
      context.howSteps.push(message);
    }
  }
}

export default InferenceEngine;
