/**
 * NLP Service - Natural Language Processing untuk Ekstrak Gejala
 * 
 * Menggunakan keyword matching sederhana untuk mengekstrak gejala
 * dari deskripsi alami user (Bahasa Indonesia).
 * 
 * Strategi: 
 * - Normalize teks (lowercase, hapus tanda baca)
 * - Cari keyword/phrase matching dengan fact descriptions
 * - Return max 2-3 gejala yang paling relevan
 */

class NLPService {
  constructor(knowledgeBase) {
    this.knowledgeBase = knowledgeBase;
    this.facts = knowledgeBase.facts;
    this.buildKeywordMap();
  }

  /**
   * Build mapping dari keywords/phrases ke fact IDs
   * Ini adalah "dictionary" untuk NLP matching
   */
  buildKeywordMap() {
    this.keywordMap = new Map();

    // Manual mapping dari keyword Indonesia ke fact ID
    const mappings = {
      // pengapian_mati - Starter tidak berbunyia atau aki mati
      'pengapian_mati': [
        'starter', 'aki', 'mati', 'tidak nyala', 'tidak hidup', 'tidak bunyi', 
        'kelistrikan', 'listrik', 'tidak menyala', 'mesin tidak hidup', 'engine start',
        'baterai', 'klik', 'cetek', 'tidak ada suara starter'
      ],

      // bensin_kosong - Tangki bensin kosong
      'bensin_kosong': [
        'bensin', 'tangki kosong', 'habis', 'jarum e', 'bensin habis', 
        'tidak ada bensin', 'bbm kosong', 'fuel', 'empty'
      ],

      // kompresi_hilang - Motor terasa lembek saat starter
      'kompresi_hilang': [
        'lembek', 'kompresi', 'tersentak', 'putaran rendah', 'no power',
        'lemah', 'tidak ada tahanan', 'tersentak sentak', 'pil kendor'
      ],

      // roda_kecil_matic - Motor Anda adalah jenis matic
      'roda_kecil_matic': [
        'matic', 'otomatis', 'transmisi otomatis', 'vario', 'beat', 'scoopy',
        'automatic', 'cvt', 'persneling otomatis'
      ],

      // rute_jalan_rusak - Sering berkendara di jalan rusak
      'rute_jalan_rusak': [
        'jalan rusak', 'berlubang', 'berlobang', 'lumpur', 'air', 'genangan',
        'jalan buruk', 'off road', 'jalan jelek', 'jalan hancur'
      ],

      // mur_baut_kendur - Ada suara berdetak atau bergoyang
      'mur_baut_kendur': [
        'berdetak', 'bergoyang', 'goyah', 'kendur', 'klotok', 'decit', 
        'suara kasar', 'suara aneh', 'getaran', 'longgar', 'baut', 'mur'
      ],

      // suku_cadang_lewat_umur - Sudah lama tidak perawatan
      'suku_cadang_lewat_umur': [
        'sudah lama', 'tidak pernah', 'belum pernah', 'perawatan', 'servis',
        'maintenance', 'umur tua', 'sudah tua', 'jarang servis', 'lama tidak servis'
      ],

      // sparepart_mutu_rendah - Menggunakan onderdil murah
      'sparepart_mutu_rendah': [
        'murah', 'kw', 'palsu', 'tidak orisinal', 'onderdil', 'spare part',
        'barang murahan', 'kualitas rendah', 'asal asalan', 'bekas'
      ],

      // suhu_di_atas_130 - Mesin terasa sangat panas
      'suhu_di_atas_130': [
        'panas', 'overheat', 'suhu tinggi', 'panas berlebih', 'mesin panas',
        'terlalu panas', 'panas sekali', 'blok panas', 'heat', 'asap'
      ],

      // air_radiator_habis - Air radiator berkurang
      'air_radiator_habis': [
        'air radiator', 'radiator', 'air habis', 'air berkurang', 'bocor',
        'kebocoran', 'air tetes', 'hose', 'coolant', 'air pendingin'
      ],

      // tarikan_gredek - Terasa berat atau gredek
      'tarikan_gredek': [
        'gredek', 'berat', 'lemah', 'gas lemah', 'tarikan lemah', 'tidak enak',
        'tersentak', 'pas pasan', 'accelerate', 'akselerasi'
      ],

      // sentrifugal_tidak_setara - Akselerasi tidak mulus
      'sentrifugal_tidak_setara': [
        'tidak mulus', 'mulus', 'akselerasi', 'jeda', 'putaran', 'rpm',
        'acceleration', 'tersentak', 'halus'
      ],

      // paking_jelek - Ada noda minyak
      'paking_jelek': [
        'minyak', 'noda', 'tetes', 'bocor', 'rembes', 'kebocoran', 'oli',
        'leak', 'tetesan', 'bekas minyak', 'oli keluar'
      ],

      // momen_baut_kurang - Goyah atau suara logam
      'momen_baut_kurang': [
        'goyah', 'goyang', 'longgar', 'lepas', 'suara logam', 'klontang',
        'suara besi', 'goyang goyang', 'bergetar'
      ],

      // tekstur_mesin_tidak_rata - Blok pernah benturan
      'tekstur_mesin_tidak_rata': [
        'benturan', 'lecet', 'rusak', 'cacat', 'tidak rata', 'penyok',
        'tergores', 'retak', 'pecah', 'damage'
      ],

      // fisik_pad_menyusut - Rem lemah
      'fisik_pad_menyusut': [
        'rem', 'kampas', 'brake', 'lembek', 'lemah', 'tidak responsif',
        'diinjak', 'pengereman', 'cengkeram', 'cengkraman'
      ],

      // sisa_kampas_10_persen - Kampas tinggal sedikit
      'sisa_kampas_10_persen': [
        'kampas tipis', 'sisa sedikit', 'tipis', 'habis', 'aus',
        'kampas aus', 'pad tipis', 'perlu ganti', 'penggantian'
      ],

      // lampu_peringatan_menyala - Lampu indikator
      'lampu_peringatan_menyala': [
        'lampu merah', 'lampu kuning', 'check engine', 'indikator', 'warning',
        'dashboard', 'error', 'alert'
      ],

      // parameter_melebihi_batas - Gejala setelah lampu
      'parameter_melebihi_batas': [
        'sejak lampu', 'setelah lampu', 'malah', 'jadi', 'anomali', 'aneh',
        'abnormal', 'tidak normal'
      ],

      // harga_sangat_murah - Beli onderdil murah
      'harga_sangat_murah': [
        'harga murah', 'lebih murah', 'harga rendah', 'grosir', 'promo',
        'diskon besar', 'murah sekali', 'harganya', 'beli murah'
      ],

      // putaran_mesin_tinggi - Sering gas penuh
      'putaran_mesin_tinggi': [
        'kecepatan tinggi', 'gas penuh', 'balap', 'balapan', 'agresif',
        'rpm tinggi', 'kecepatan', 'ngebut', 'gas max', 'full throttle'
      ]
    };

    // Store mappings
    Object.entries(mappings).forEach(([factId, keywords]) => {
      keywords.forEach(keyword => {
        if (!this.keywordMap.has(keyword)) {
          this.keywordMap.set(keyword, []);
        }
        this.keywordMap.get(keyword).push(factId);
      });
    });
  }

  /**
   * Normalize teks: lowercase, hapus tanda baca, trim whitespace
   */
  normalizeText(text) {
    return text
      .toLowerCase()
      .replace(/[^\w\s]/g, '') // Hapus tanda baca
      .trim();
  }

  /**
   * Extract gejala dari teks alami
   * Returns: {symptoms: [{factId, label, confidence, matchedKeyword}], raw: string}
   */
  extractSymptoms(userInput) {
    const normalized = this.normalizeText(userInput);
    const words = normalized.split(/\s+/).filter(w => w.length > 0);
    
    // Score system untuk fact candidates
    const factScores = new Map();

    // Match keywords - bisa multi-word
    for (const [keyword, factIds] of this.keywordMap.entries()) {
      const keywordWords = keyword.split(/\s+/);
      
      // Check jika keyword ada di teks (sequential atau spread out)
      if (this.matchPhrase(words, keywordWords)) {
        for (const factId of factIds) {
          const current = factScores.get(factId) || { score: 0, keyword: keyword };
          current.score += keywordWords.length; // Semakin panjang keyword, semakin akurat
          factScores.set(factId, current);
        }
      }
    }

    // Sort by score dan ambil top 3
    const sorted = Array.from(factScores.entries())
      .sort((a, b) => b[1].score - a[1].score)
      .slice(0, 3)
      .map(([factId, { score, keyword }]) => ({
        factId,
        fact: this.knowledgeBase.factsById.get(factId),
        score,
        matchedKeyword: keyword
      }));

    return {
      symptoms: sorted,
      raw: userInput,
      confidence: sorted.length > 0 ? (sorted[0].score / 5) : 0 // Rough confidence calc
    };
  }

  /**
   * Helper: Match phrase dari word array
   * Fleksibel - bisa sequential atau spread
   */
  matchPhrase(words, phraseWords) {
    if (phraseWords.length === 0) return false;
    if (phraseWords.length > words.length) return false;

    // Try sequential match first
    for (let i = 0; i <= words.length - phraseWords.length; i++) {
      const slice = words.slice(i, i + phraseWords.length);
      if (slice.every((w, idx) => w === phraseWords[idx])) {
        return true;
      }
    }

    // Try spread match (all phrase words exist in sequence order)
    let phraseIdx = 0;
    for (const word of words) {
      if (word === phraseWords[phraseIdx]) {
        phraseIdx++;
        if (phraseIdx === phraseWords.length) {
          return true;
        }
      }
    }

    return false;
  }

  /**
   * Extract single fact dengan highest confidence
   * Berguna untuk simple query
   */
  extractTopSymptom(userInput) {
    const result = this.extractSymptoms(userInput);
    return result.symptoms[0] || null;
  }

  /**
   * Extract multiple symptoms dan convert ke working memory format
   * Format: {factId: true/false}
   */
  extractAsWorkingMemory(userInput) {
    const result = this.extractSymptoms(userInput);
    const memory = {};

    result.symptoms.forEach(({ factId }) => {
      memory[factId] = true;
    });

    return {
      memory,
      extractedFacts: result.symptoms.map(s => ({
        id: s.factId,
        label: s.fact.label,
        confidence: s.score
      })),
      totalExtracted: result.symptoms.length
    };
  }

  /**
   * Parse jawaban text user untuk determine YES atau NO
   * Strategy: 
   * - Check untuk YES keywords (positif/mengakui gejala)
   * - Check untuk NO keywords (negasi/tidak ada gejala)
   * - Return boolean value dan confidence score
   * 
   * @param {string} answerText - Jawaban dari user
   * @param {string} questionType - Tipe pertanyaan (optional, untuk context)
   * @returns {object} { value: true/false, confidence: 0-100 }
   */
  parseAnswer(answerText) {
    if (!answerText || typeof answerText !== 'string') {
      return { value: false, confidence: 0 };
    }

    const normalized = this.normalizeText(answerText);
    const words = normalized.split(/\s+/).filter(w => w.length > 0);

    // Keywords untuk jawaban POSITIF (Iya, benar, ada, dsb)
    const yesKeywords = [
      'iya', 'ya', 'iya iya', 'benar', 'betul', 'tepat', 'iya benar',
      'ada', 'pernah', 'ada itu', 'ada ya', 'ada tuh', 'ada sih',
      'pernah itu', 'pernah ada', 'pernah ya', 'pengalaman',
      'sering', 'sering kali', 'hampir selalu', 'banyak', 'banyak kali',
      'biasa', 'biasa itu', 'normal', 'wajar',
      'yep', 'yup', 'indeed', 'correct', 'exactly',
      'bener', 'beneran', 'jadi', 'udah', 'sudah', 'pernah banget',
      'setiap', 'tiap', 'selalu', 'terus', 'terus menerus',
      'kelihatan', 'terlihat', 'tampak', 'nampak', 'keliatan'
    ];

    // Keywords untuk jawaban NEGATIF (Tidak, nggak, tidak ada, dsb)
    const noKeywords = [
      'tidak', 'nggak', 'enggak', 'gak', 'tidak ada', 'nggak ada',
      'belum', 'belum pernah', 'tidak pernah', 'nggak pernah',
      'tidak pernah ada', 'nggak pernah ada', 'tidak pernah sih',
      'jarang', 'jarang sih', 'hampir tidak pernah', 'jarang banget',
      'tidak biasa', 'nggak biasa', 'aneh kalo', 'tidak wajar',
      'nope', 'nope', 'no', 'never', 'not at all', 'definitely not',
      'sama sekali tidak', 'tidak sama sekali', 'engga', 'tidak pernah',
      'tidak terasa', 'tidak terlihat', 'tidak kelihatan', 'tidak ada yang',
      'normal normal', 'biasa aja', 'lancar', 'baik baik', 'baik saja'
    ];

    // Count matches
    let yesCount = 0;
    let noCount = 0;

    for (const word of words) {
      if (yesKeywords.includes(word)) yesCount++;
      if (noKeywords.includes(word)) noCount++;
    }

    // Prioritas NO karena sering user mengatakan "tidak" lebih eksplisit
    // Kalau noCount > yesCount atau noCount > 0 dan yesCount == 0, return NO
    if (noCount > yesCount || (noCount > 0 && yesCount === 0)) {
      const confidence = Math.min(100, (noCount / Math.max(words.length, 1)) * 100);
      return {
        value: false,
        confidence: Math.round(confidence),
        matchedKeywords: words.filter(w => noKeywords.includes(w))
      };
    }

    // Otherwise, check jika ada yes keywords
    if (yesCount > 0) {
      const confidence = Math.min(100, (yesCount / Math.max(words.length, 1)) * 100);
      return {
        value: true,
        confidence: Math.round(confidence),
        matchedKeywords: words.filter(w => yesKeywords.includes(w))
      };
    }

    // Default: tidak terdefinisi, assume NO dengan confidence rendah
    return {
      value: false,
      confidence: 20,
      reason: 'Tidak dapat memastikan jawaban, asumsikan tidak'
    };
  }
}

export default NLPService;
