import { randomUUID } from "node:crypto";

class SessionStore {
  constructor({ ttlMinutes = 30 } = {}) {
    this.ttlMs = ttlMinutes * 60 * 1000;
    this.sessions = new Map();

    const cleaner = setInterval(() => this.cleanup(), 5 * 60 * 1000);
    cleaner.unref?.();
  }

  create(goalId) {
    const now = new Date().toISOString();
    const session = {
      id: randomUUID(),
      goalId,
      workingMemory: {},
      currentQuestion: null,
      reasoningLog: [],
      trace: [],
      lastResult: null,
      createdAt: now,
      updatedAt: now
    };

    this.sessions.set(session.id, session);
    return session;
  }

  get(sessionId) {
    const session = this.sessions.get(sessionId);

    if (!session) {
      return null;
    }

    if (Date.now() - new Date(session.updatedAt).getTime() > this.ttlMs) {
      this.sessions.delete(sessionId);
      return null;
    }

    return session;
  }

  touch(session) {
    session.updatedAt = new Date().toISOString();
    return session;
  }

  clearDerivedFacts(session) {
    const nextMemory = {};

    for (const [factId, factState] of Object.entries(session.workingMemory)) {
      if (factState.source === "user") {
        nextMemory[factId] = factState;
      }
    }

    session.workingMemory = nextMemory;
    session.lastResult = null;
    session.trace = [];
    session.reasoningLog = [];
    session.currentQuestion = null;
    this.touch(session);
    return session;
  }

  recordUserFact(session, factId, value) {
    this.clearDerivedFacts(session);
    session.workingMemory[factId] = {
      value,
      source: "user",
      updatedAt: new Date().toISOString()
    };

    return this.touch(session);
  }

  delete(sessionId) {
    return this.sessions.delete(sessionId);
  }

  cleanup() {
    for (const [sessionId, session] of this.sessions.entries()) {
      if (Date.now() - new Date(session.updatedAt).getTime() > this.ttlMs) {
        this.sessions.delete(sessionId);
      }
    }
  }
}

export default SessionStore;
