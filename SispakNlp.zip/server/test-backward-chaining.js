/**
 * TEST - Backward Chaining DFS Logic
 * 
 * File ini mendemonstrasikan bagaimana sistem bekerja dengan contoh concrete.
 * Jalankan: node test-backward-chaining.js (di folder server)
 */

import fs from "node:fs";

// Simulasi Knowledge Base
const rulesData = JSON.parse(fs.readFileSync("./src/data/rules.json", "utf-8"));

class SimpleDFSEngine {
  constructor(kb) {
    this.kb = kb;
    this.goalStack = [];
    this.memo = {};
    this.steps = [];
  }

  prove(targetId) {
    this.steps = [];
    this.memo = {};
    const result = this.dfs(targetId);
    return {
      goal: targetId,
      result: result.proven,
      steps: this.steps
    };
  }

  dfs(targetId, depth = 0) {
    const indent = "  ".repeat(depth);

    // Deteksi siklus
    if (this.goalStack.includes(targetId)) {
      this.steps.push(`${indent}⚠️ SIKLUS TERDETEKSI: ${targetId}`);
      return { proven: false };
    }

    // Cek memo
    if (this.memo[targetId] !== undefined) {
      this.steps.push(`${indent}📌 MEMO HIT: ${targetId} = ${this.memo[targetId]}`);
      return { proven: this.memo[targetId] };
    }

    this.goalStack.push(targetId);

    // Cari rule yang menyimpulkan targetId
    const goal = this.kb.goalsById.get(targetId);
    const rules = this.kb.rulesByConclusion.get(targetId) ?? [];

    if (rules.length === 0) {
      this.steps.push(`${indent}❌ TIDAK ADA RULE untuk membuktikan: ${targetId}`);
      this.memo[targetId] = false;
      this.goalStack.pop();
      return { proven: false };
    }

    // DFS setiap rule
    for (const rule of rules) {
      this.steps.push(`${indent}🔍 COBA RULE ${rule.id}: ${rule.premises.join(" AND ")} → ${targetId}`);

      let allProven = true;

      // Buktikan setiap premise
      for (const premise of rule.premises) {
        const premiseResult = this.dfs(premise, depth + 1);
        if (!premiseResult.proven) {
          allProven = false;
          this.steps.push(`${indent}  ❌ PREMISE GAGAL: ${premise} tidak terbukti`);
          break;
        }
      }

      // Jika semua premise terbukti
      if (allProven) {
        this.steps.push(`${indent}✅ RULE BERHASIL: ${rule.id}`);
        this.steps.push(`${indent}✓ TERBUKTI: ${targetId}`);
        this.memo[targetId] = true;
        this.goalStack.pop();
        return { proven: true };
      }
    }

    // Semua rule gagal
    this.steps.push(`${indent}❌ SEMUA RULE GAGAL untuk: ${targetId}`);
    this.memo[targetId] = false;
    this.goalStack.pop();
    return { proven: false };
  }
}

// Setup Knowledge Base
const goalsById = new Map(rulesData.goals.map((g) => [g.id, g]));
const factsById = new Map(rulesData.facts.map((f) => [f.id, f]));
const rulesByConclusion = rulesData.rules.reduce((map, rule) => {
  const bucket = map.get(rule.conclusion) ?? [];
  bucket.push(rule);
  map.set(rule.conclusion, bucket);
  return map;
}, new Map());

const kb = { goalsById, factsById, rulesByConclusion };

// TEST 1: Buktikan "mesin_mati_total"
console.log("=" * 60);
console.log("TEST 1: Prove 'mesin_mati_total' dengan premise 'bensin_kosong'");
console.log("=" * 60);

const engine1 = new SimpleDFSEngine(kb);

// Simulasi user menjawab "bensin_kosong = true"
engine1.memo["bensin_kosong"] = true;

const test1 = engine1.prove("mesin_mati_total");
console.log("\nTRACE:");
test1.steps.forEach((s) => console.log(s));
console.log(`\nRESULT: ${test1.result ? "✅ PROVEN" : "❌ NOT PROVEN"}`);

// TEST 2: Buktikan "bearing_roda_rusak" membutuhkan 2 premise
console.log("\n" + "=" * 60);
console.log("TEST 2: Prove 'bearing_roda_rusak' (membutuhkan 2 premise AND)");
console.log("=" * 60);

const engine2 = new SimpleDFSEngine(kb);

// User hanya menjawab 1 dari 2 premise
engine2.memo["roda_kecil_matic"] = true;
engine2.memo["rute_jalan_rusak"] = true; // HARUS 2 premise PROVEN

const test2 = engine2.prove("bearing_roda_rusak");
console.log("\nTRACE:");
test2.steps.forEach((s) => console.log(s));
console.log(`\nRESULT: ${test2.result ? "✅ PROVEN" : "❌ NOT PROVEN"}`);

// TEST 3: Buktikan "mesin_overheat" dengan 1 premise salah
console.log("\n" + "=" * 60);
console.log("TEST 3: Prove 'mesin_overheat' (hanya 1 dari 2 premise)");
console.log("=" * 60);

const engine3 = new SimpleDFSEngine(kb);

engine3.memo["suhu_di_atas_130"] = true;
engine3.memo["air_radiator_habis"] = false; // GAGAL, harus TRUE

const test3 = engine3.prove("mesin_overheat");
console.log("\nTRACE:");
test3.steps.forEach((s) => console.log(s));
console.log(`\nRESULT: ${test3.result ? "✅ PROVEN" : "❌ NOT PROVEN"}`);

console.log("\n" + "=" * 60);
console.log("KESIMPULAN:");
console.log("=" * 60);
console.log(`
1. LOGIKA BOOLEAN MURNI: Tidak ada CF/confidence
2. HASIL PASTI: Hanya TRUE atau FALSE, tidak ada gradasi
3. DFS ALGORITHM: Satu jalur rule dicoba sampai habis sebelum lanjut
4. ALL-OR-NOTHING: Semua premise HARUS TRUE agar rule berhasil
5. MEMOIZATION: Hasil sudah terbukti disimpan untuk efisiensi
`);
